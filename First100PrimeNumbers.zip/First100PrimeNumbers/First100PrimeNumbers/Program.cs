﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace First100PrimeNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            //1. I decided to start from the four primary numbers below ten.
            //2. If any number has a remainder when divided by any of these four primary numbers (2,3,5,7)  - it should be considered a prime number. 
            int num = 1;
            int max = 0;
            double primeNo = 2;
            int[] numbers = new int[100];
            
            while (num < 3000)
            {
                if (primeNo == 2 || primeNo == 3 || primeNo == 5 || primeNo == 7)
                {
                    numbers[max] = Convert.ToInt32(primeNo);
                    ++max;
                }
                else if ((primeNo / 2) % 1 != 0 && (primeNo / 3) % 1 != 0 && (primeNo / 5) % 1 != 0 && (primeNo / 7) % 1 != 0)
                {
                    numbers[max] = Convert.ToInt32(primeNo);
                    ++max;
                }

                if (max == 100) { break; }
                else { ++num; ++primeNo; }

            }

            //3. Lastly - I display the first 100 prime numbers.
            for (int i = 0; i < numbers.Length; i++)
            {
                Console.WriteLine((i + 1) + ".  " + numbers[i]);
            }
            Console.Read();
        }
    }
}
